CREATE DATABASE roundcubedb;
CREATE USER roundcube@localhost IDENTIFIED BY 'RoundCube123';
GRANT ALL PRIVILEGES on roundcubedb.* to roundcube@localhost ;
FLUSH PRIVILEGES;
exit
