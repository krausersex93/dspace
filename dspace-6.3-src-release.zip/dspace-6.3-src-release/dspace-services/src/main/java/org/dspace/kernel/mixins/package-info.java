/**
 * The contents of this file are subject to the license and copyright
 * detailed in the LICENSE and NOTICE files at the root of the source
 * tree and available online at
 *
 * http://www.dspace.org/license/
 */
/**
 * Interfaces for interacting with the startup, shutdown, or 
 * reconfiguration of the framework.
 */

package org.dspace.kernel.mixins;
